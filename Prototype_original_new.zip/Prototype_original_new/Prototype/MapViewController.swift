//
//  MapViewController.swift
//  Prototype
//
//  Created by Kevin Qian on 10/13/16.
//  Copyright © 2016 Kevin Qian. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Parse

var publicAnnoList: [AnnoMark] = [];

class MapViewController: UIViewController, MKMapViewDelegate, UITextFieldDelegate, CLLocationManagerDelegate {

    public static var instance: MapViewController?;
    
    public static func getClassAnnoList() -> [AnnoMark] {
        if let arr = instance?.annoList {
            return arr;
        } else {
            return [];
        }
    }
    
    //////ANNOLIST
    public var annoList: [AnnoMark] = [];
    var notYetNotifiedAnnoList: [AnnoMark] = [];
    func annoList_isPresent(pfobj: PFObject) -> Bool {
        for obj in annoList {
            if AnnoMark.compare(obj: obj, pfobj: pfobj) == true {
                return true
            }
        }
        return false;
    }
    func annoList_scanRangeAndDelete() {
        var i = 0;
        if (annoList.count == 0) {
            return;
        }
        while i < annoList.count {
            var anno = annoList[i];
            
            if userLocation.distance(from: CLLocation(latitude: anno.annotation!.coordinate.latitude, longitude: anno.annotation!.coordinate.longitude)) > Double(detect_range) {
                AnnoMark.remove(obj: anno);
                annoList.remove(at: i);
            }
            i += 1;
        }
    }
    
    var publicAnnoListTimer: Timer = Timer();
    func refreshPublicAnnoList() {
        publicAnnoList = annoList;
    }
    
    /////////
    func createNewAnnoNotification() {
        var i = 0;
        
        var tuples: [(Int, Double)] = []
        
        if (notYetNotifiedAnnoList.count == 0) {
            return;
        }
        
        while i < notYetNotifiedAnnoList.count {
            var anno = notYetNotifiedAnnoList[i];
            
            var dist = userLocation.distance(from: CLLocation(latitude: anno.annotation!.coordinate.latitude, longitude: anno.annotation!.coordinate.longitude))
            
            if dist > Double(detect_range) {
                notYetNotifiedAnnoList.remove(at: i);
            } else {
                tuples.append((i, dist));
            }
            i += 1;
        }
        
        if tuples.count <= 0 {
            return;
        }
        
        var select: (Int, Double) = tuples[0];
        for tuple in tuples {
            if tuple.1 < select.1 {
                select = tuple;
            }
        }
        
        createNotification(message: notYetNotifiedAnnoList[select.0].annotation!.title!!);
        notYetNotifiedAnnoList.remove(at: Int(select.0));
    }
    
    /////////
    /////////
    
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation {
            //return nil
            return nil
        }
        
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.pinTintColor = UIColor(hue: 0.5556, saturation: 1, brightness: 1, alpha: 1.0)
            pinView!.canShowCallout = true
            pinView!.animatesDrop = true
        }
        
        
        /*
        if annotation.subtitle! == "Audio" {
            //            var PlayBTN: UIButton!
            //            //PlayBTN.debugDescription = annotation.debugDescription
            //            PlayBTN.setTitle("Play", for: .normal)
            
            let button = PlayBTN//UIButton(type: UIButtonType.detailDisclosure) as UIButton // button with info sign in it
            pinView?.rightCalloutAccessoryView = button
        }
        */
        
        return pinView
    }
    
    
    @IBOutlet var map: MKMapView!
    
    @IBOutlet var o_tf_msgTextField: UITextField!
    
    var userLocation: CLLocation!

    
    /////////////////////////////////
    //Region: Text field/Send Management
    /////////////////////////////////
    func init_textfield() {
        o_tf_msgTextField.frame = CGRect(x: 64, y: 552, width: 0, height: 30)
        setTextfieldHidden()
        o_bt_popTextField.setNeedsDisplay()
        
        o_bt_send.alpha = 0
        o_bt_send.isEnabled = false
    }
    
    var tf_timer: Timer = Timer()
    func setTextfieldActive() {
        o_tf_msgTextField.isHidden = false
        tf_state = .shown
    }
    func setTextfieldHidden() {
        o_tf_msgTextField.isHidden = true
        tf_state = .hidden
    }
    enum textFieldStates {
        case shown
        case hidden
        case none
    }
    //var isTextFieldShown = false;
    var tf_state: textFieldStates = .hidden
    @IBOutlet var o_bt_popTextField: UIButton!
    @IBOutlet var o_bt_send: UIButton!
    
    //Pop text field and rotate the button
    @IBAction func a_bt_popTextField(_ sender: AnyObject) {
        if isKeyboardShown == true {
            //FIXME: better animation
            return
        }
        
        
        if tf_state == .hidden {
            tf_timer.invalidate()
            tf_state = .none //avoid action collisions
            setTextfieldActive()
            UIView.animate(withDuration: 0.7, animations: {
                self.o_tf_msgTextField.frame = CGRect(x: 81, y: 552, width: 213, height: 30)
                self.o_bt_popTextField.transform = CGAffineTransform(rotationAngle: CGFloat.pi / 2)
                self.o_bt_send.alpha = 1
            })
            o_bt_send.isEnabled = true
            //isTextFieldShown = true
        } else if tf_state == .shown {
            tf_timer.invalidate()
            tf_state = .none //avoid action collisions
            tf_timer = Timer.scheduledTimer(timeInterval: 0.7, target: self, selector: #selector(MapViewController.setTextfieldHidden), userInfo: nil, repeats: false)
            
            UIView.animate(withDuration: 0.7, animations: {
                self.o_tf_msgTextField.frame = CGRect(x: 64, y: 552, width: 0, height: 30)
                self.o_bt_popTextField.transform = CGAffineTransform(rotationAngle: CGFloat(0))
                
                self.o_bt_send.alpha = 0
            })
            o_bt_send.isEnabled = false
            //isTextFieldShown = false
        }
    }
    //send button
    @IBAction func a_bt_send(_ sender: AnyObject) {
        if !((o_tf_msgTextField.text?.isEmpty)!) {
            sendMessage()
            o_tf_msgTextField.text = ""
        }
    }
    
    
    func addToMap(object: PFObject) {
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: object["Latitude"] as! CLLocationDegrees, longitude: object["Longitude"] as! CLLocationDegrees)
        annotation.title = object["Message"] as! String
        
        print(annotation.title);
        map.addAnnotation(annotation)
        //annotationList.append(annotation);
    }

    func refreshMessages(){
        //let allAnnotations = self.map.annotations
        //self.map.removeAnnotations(allAnnotations)
        
        var receivedMessages = [PFObject]()
        let query = PFQuery(className: "Messages")
        query.findObjectsInBackground { (objects, error) -> Void in
            if objects != nil {
                
                for object in objects! as [PFObject] {
                    if self.userLocation.distance(from: CLLocation(latitude: object["Latitude"] as! CLLocationDegrees, longitude: object["Longitude"] as! CLLocationDegrees)) <= Double(detect_range)  {
                        
                        if self.annoList_isPresent(pfobj: object) {
                            continue;
                        }
                        
                        receivedMessages.append(object)
                        print("count: \(objects?.count)");
                        /////////////
                        //self.addToMap(object: object)
                        /////////////
                        var anno = AnnoMark.createAndAddToMap(object)
                        self.annoList.append(anno);
                        self.notYetNotifiedAnnoList.append(anno);
                        /*
                        if (notNotified == true) {
                            notNoti
                        }
                         */
                    }
                    
                }
                
                //self.createNotification(message: objects?[0]["Message"] as! String);
                
                
            } else {
                
                if error != nil {
                    
                    print (error)
                    
                } else {
                    
                    print ("Error!")
                    
                }
            }
        }
        
        
        
        annoList_scanRangeAndDelete();
        //return receivedMessages
    }
    
    func sendMessage() {
        let newMessage = PFObject(className: "Messages")
        
        let msg_with_username: String = usr_name + ": " + o_tf_msgTextField.text!
        //newMessage["Message"] = o_tf_msgTextField.text!
        newMessage["Message"] = msg_with_username
        newMessage["Latitude"] = userLocation.coordinate.latitude
        newMessage["Longitude"] = userLocation.coordinate.longitude
        newMessage.saveInBackground { (success, error) -> Void in
            if success {
                
                print("Object has been saved.")
                
            } else {
                
                if error != nil {
                    
                    print (error)
                    
                } else {
                    
                    print ("Error")
                }
                
            }
        }
        //addToMap();
        refreshMessages()
        o_tf_msgTextField.text = "";
        /*if TestMessages.count > 0 {
         o_tf_msgTextField.text = TestMessages[0]["Message"] as! String + " Received!"
         }*/
    }
    
    
    var refreshTimer : Timer = Timer();
    var notificationTimer: Timer = Timer();
    
    
    /////////////////////////////////
    //Region: Location Services
    /////////////////////////////////
    var locationManager = CLLocationManager()
    
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        userLocation = locations[0]
        
        setMap(userLocation: userLocation)
        
    }
    
    func setMap(userLocation: CLLocation){
        
        let latDelta: CLLocationDegrees = 0.25 / 69 //each degree is about 69 miles
        
        let lonDelta: CLLocationDegrees = 0.25 / 69 //each degree is about 69 miles
        
        let span: MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: lonDelta)
        
        let location: CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: userLocation.coordinate.latitude, longitude: userLocation.coordinate.longitude)
        
        let region: MKCoordinateRegion = MKCoordinateRegion(center: location, span: span)
        
        map.setRegion(region, animated: true)
        
    }
    
    /*
    func addToMap() {
        let annotation = MKPointAnnotation()
        annotation.coordinate = userLocation.coordinate
        annotation.title = o_tf_msgTextField.text!
        
        o_tf_msgTextField.text = "";
        map.addAnnotation(annotation)
    }
     */
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        endTextfieldEditing()
        //self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {// called when return key pressed
        
        textField.resignFirstResponder()
        UIView.animate(withDuration: 0.1, animations: { () -> Void in
            self.o_tf_msgTextField.frame = CGRect(x: 81, y: 552, width: 213, height: 30)
        })
        
        return true
        
    }
    
    var isKeyboardShown = false
    
    func keyboardWillShow(notification: NSNotification) {
        isKeyboardShown = true
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardFrame: NSValue = userInfo.value(forKey: UIKeyboardFrameEndUserInfoKey) as! NSValue
        let keyboardRectangle = keyboardFrame.cgRectValue
        let keyboardHeight = keyboardRectangle.height
        setEditPosition(keyboardHeight: keyboardHeight)
    }
    
    func keyboardWillHide(notification: NSNotification) {
        isKeyboardShown = false
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
        let keyboardFrame: NSValue = userInfo.value(forKey: UIKeyboardFrameEndUserInfoKey) as! NSValue
        let keyboardRectangle = keyboardFrame.cgRectValue
        let keyboardHeight = keyboardRectangle.height
        setEditPosition(keyboardHeight: keyboardHeight)
    }
    
    let screenSize: CGRect = UIScreen.main.bounds
    
    func setEditPosition(keyboardHeight: CGFloat) {
        UIView.animate(withDuration: 0.1, animations: { () -> Void in
            self.o_tf_msgTextField.frame = CGRect(x: 81, y:
                self.screenSize.height - keyboardHeight - 31, width: 213, height: 30)
            self.o_bt_popTextField.frame = CGRect(x: 17, y:  self.screenSize.height - keyboardHeight - 49, width: 50, height: 50)
            self.o_bt_send.frame = CGRect(x: 308, y: self.screenSize.height - keyboardHeight - 41, width: 51, height: 50)
        })
    }
    
    func endTextfieldEditing() {
        self.view.endEditing(true)
        if tf_state == .shown {
            UIView.animate(withDuration: 0.1, animations: { () -> Void in
                self.o_tf_msgTextField.frame = CGRect(x: 81, y: 552, width: 213, height: 30)
                self.o_bt_popTextField.frame = CGRect(x: 17, y: 543, width: 50, height: 50)
                self.o_bt_send.frame = CGRect(x: 308, y: 542, width: 51, height: 50)
            })
        }
    }
    
    
    
    var notifyTimer: Timer = Timer();
    override func viewDidAppear(_ animated: Bool) {
        init_textfield()
        
        NotificationCenter.default.addObserver(self, selector: #selector(MapViewController.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(MapViewController.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    var backgroundTaskIdentifier: UIBackgroundTaskIdentifier = 0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        map.delegate = self
        
        MapViewController.instance = self;
        
        AnnoMark.setMap(map: map);
        
        // Do any additional setup after loading the view, typically from a nib.
        
        
        //o_tf_msgTextField.isHidden = true
        
        /* GPS STUFF */
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        
        //notifyTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(scheduleLocal), userInfo: nil, repeats: true)
        
        
        backgroundTaskIdentifier = UIApplication.shared.beginBackgroundTask(expirationHandler: {
            UIApplication.shared.endBackgroundTask(self.backgroundTaskIdentifier)
        })
        refreshTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(refreshMessages), userInfo: nil, repeats: true)
        notificationTimer = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(createNewAnnoNotification), userInfo: nil, repeats: true)
        publicAnnoListTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(refreshPublicAnnoList), userInfo: nil, repeats: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //////////NOTIFICATION
    func setupNotificationSettings() {
        
        var notify = UIMutableUserNotificationAction();
        notify.identifier = "Notify";
        notify.title = "Notification!";
        notify.activationMode = UIUserNotificationActivationMode.foreground;
        notify.isDestructive = true;
        notify.isAuthenticationRequired = true;
        
        var notifyCategory = UIMutableUserNotificationCategory()
        notifyCategory.identifier = "notifyCategory"
        notifyCategory.setActions(NSArray(objects: notify) as? [UIUserNotificationAction], for: UIUserNotificationActionContext.default);
        
        let categoriesForSettings = NSSet(objects: notifyCategory);
        let newNotificationSettings = UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: categoriesForSettings as? Set<UIUserNotificationCategory>)
        UIApplication.shared.registerUserNotificationSettings(newNotificationSettings)
    }
    
    func createNotification(message: String) {
        var localNotification = UILocalNotification()
        //localNotification.fireDate = Date(timeIntervalSinceNow: 1)
        //print(Date(timeIntervalSinceNow: 1));
        localNotification.alertBody = message;
        localNotification.applicationIconBadgeNumber = 1;
        localNotification.soundName = UILocalNotificationDefaultSoundName;
        localNotification.userInfo = [
            "message": "look!"
        ]
        localNotification.fireDate = Date(timeIntervalSinceNow: 1);
        //localNotification.timeZone = NSCalendar.current.timeZone;
        localNotification.category = "notifyCategory";
        
        UIApplication.shared.scheduleLocalNotification(localNotification);
    }
    
    func createAlert() {
        let alertController = UIAlertController(title: "test", message: "baaa", preferredStyle: .alert)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.o_bt_popTextField.transform = CGAffineTransform(rotationAngle: 0)
        
        tf_state = .none //avoid action collisions
        setTextfieldHidden()

        self.o_tf_msgTextField.frame = CGRect(x: 64, y: 552, width: 0, height: 30)
        self.o_bt_popTextField.transform = CGAffineTransform(rotationAngle: CGFloat(0))
            
        self.o_bt_send.alpha = 0
        
        o_bt_send.isEnabled = false
    }
}

