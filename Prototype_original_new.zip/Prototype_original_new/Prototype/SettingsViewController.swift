//
//  SettingsViewController.swift
//  Prototype
//
//  Created by Kevin Qian on 10/13/16.
//  Copyright © 2016 Kevin Qian. All rights reserved.
//

import UIKit

let USER_NAME = "USER NAME"
var usr_name: String!

let DETECT_RANGE = "DETECT RANGE"
var detect_range: Int = 30

class SettingsViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    @IBOutlet var o_tf_username: UITextField!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {// called when return key pressed
        textField.resignFirstResponder()
        return true
        
    }
    
    func endUsernameEditing() {
        self.view.endEditing(true)
        if o_tf_username.text == nil {
            o_tf_username.text = ""
        }
        usr_name = o_tf_username.text!
        UserDefaults.standard.set(o_tf_username.text!, forKey: USER_NAME)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        endUsernameEditing()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        o_tf_username.text = ""
        usr_name = UserDefaults.standard.string(forKey: USER_NAME)
        if usr_name != nil {
            o_tf_username.text = usr_name!
        }
        
        o_tf_pickerRange.text = ""
        detect_range = UserDefaults.standard.integer(forKey: DETECT_RANGE)
        if detect_range != nil {
            o_tf_pickerRange.text = String(describing: detect_range)
        }
        
        o_tf_pickerRange.delegate = self
    }
    
    @IBOutlet var o_tf_pickerRange: UITextField!
    @IBOutlet var o_pk_dropDown: UIPickerView!
    
    var range = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    // returns the # of rows in each component..
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return range.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        return String(describing: range[row])
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.o_tf_pickerRange.text = String(describing: self.range[row])
        if row == 0 {
            detect_range = 0
        } else {
            detect_range = self.range[row]
        }
        UserDefaults.standard.set(detect_range, forKey: DETECT_RANGE)
        self.o_pk_dropDown.isHidden = true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == o_tf_pickerRange {
            self.o_pk_dropDown.isHidden = false
            o_tf_username.endEditing(true)
            endUsernameEditing()
        }
    }
}
