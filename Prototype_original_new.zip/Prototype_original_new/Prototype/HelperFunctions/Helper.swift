//
//  Helper.swift
//  Prototype
//
//  Created by Kevin Qian on 10/17/16.
//  Copyright © 2016 Kevin Qian. All rights reserved.
//

import Foundation

class Utils {
    public class string {
        static func concat() {
            
        }
    }
}
