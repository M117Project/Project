//
//  Classes.swift
//  Prototype
//
//  Created by Kevin Qian on 11/15/16.
//  Copyright © 2016 Kevin Qian. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreLocation
import Parse

public class AnnoMark {
    init() {
        //
    }
    
    init(_ annotation: MKAnnotation, id: String) {
        self.annotation = annotation;
        self.id = id;
    }
    public var annotation: MKAnnotation? = nil;
    public var id: String = "";
    public var map: MKMapView? = nil;
    
    public static func compare(obj_1: AnnoMark, obj_2: AnnoMark) -> Bool {
        if (obj_1.id == obj_2.id) {
            return true;
        }
        return false;
    }
    
    public static func compare(obj: AnnoMark, pfobj: PFObject) -> Bool {
        if (obj.id == (pfobj.objectId!)) {
            return true;
        }
        return false;
    }
    
    public static func create(_ pfobj: PFObject) -> AnnoMark {
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: pfobj["Latitude"] as! CLLocationDegrees, longitude: pfobj["Longitude"] as! CLLocationDegrees)
        annotation.title = pfobj["Message"] as? String
        return AnnoMark(annotation, id: pfobj.objectId!);
    }
    
    public static func createAndAddToMap(_ pfobj: PFObject) -> AnnoMark {
        let anno = AnnoMark.create(pfobj);
        
        instance.map!.addAnnotation(anno.annotation!);
        return anno;
    }
    
    public static func remove(obj: AnnoMark) {
        instance.map!.removeAnnotation(obj.annotation!);
    }
    
    public static func setMap(map: MKMapView) {
        instance.map = map;
    }
    public static var instance: AnnoMark = AnnoMark();
}
