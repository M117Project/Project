//
//  ExploreViewController.swift
//  Prototype
//
//  Created by Kevin Qian on 10/13/16.
//  Copyright © 2016 Kevin Qian. All rights reserved.
//

import UIKit

class ExploreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var localAnnoMarks: [AnnoMark] = [];

    @IBOutlet weak var o_tb_exploreTable: UITableView!
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    internal func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return localAnnoMarks.count
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "Cell");
        
        //mapViewDelegate!.updateExploreControllerAnnoMarks(controller: self);
        if (indexPath.row >= publicAnnoList.count) {
            return cell;
        }
        cell.textLabel?.text = publicAnnoList[indexPath.row].annotation!.title!;
        return cell;
    }
    
    /*
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
 */
    
    
    
    private func tableReloadData() {
        o_tb_exploreTable.reloadData();
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.o_tb_exploreTable.dataSource = self
        self.o_tb_exploreTable.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
        initRefresh();
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    //////REFRESH///////
    var refreshControl: UIRefreshControl!
    func initRefresh() {
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(refresh), for: UIControlEvents.valueChanged)
        self.o_tb_exploreTable.addSubview(refreshControl)
    }
    
    func refresh() {
        reloadData()
        self.refreshControl.endRefreshing()
        o_tb_exploreTable.reloadData()
    }
    
    func reloadData() {
        localAnnoMarks = MapViewController.getClassAnnoList()
        o_tb_exploreTable.reloadData();
    }

}

